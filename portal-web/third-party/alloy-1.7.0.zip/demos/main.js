var YUI = require('../build/yui/yui.js').YUI;

var AUI_config = require('../build/aui-base/aui-base-meta.js').AUI_config;

var Y = YUI(
{
base: '../build',
combine: false
}
);

for (var group in AUI_config.groups) {
Y.Env._loader.addGroup(AUI_config.groups[group], group);
}

var moduleInfo = Y.Env._loader.moduleInfo;

/*
debugger;

Y.Env._loader.require('aui-event');

var resolved = Y.Env._loader.resolve(true);

console.log(resolved);

Y.Env._loader.required = {};
*/
Y.Env._loader.require('aui-dialog-iframe', 'aui-swf');

var resolved2 = Y.Env._loader.resolve(true);

console.log(resolved2);
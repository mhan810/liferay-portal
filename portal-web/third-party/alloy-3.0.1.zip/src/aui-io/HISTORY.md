# AUI I/O

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-io).

## @VERSION@

No registries yet.

## [3.0.1](https://github.com/liferay/alloy-ui/releases/tag/3.0.1)

No changes.

## [3.0.0](https://github.com/liferay/alloy-ui/releases/tag/3.0.0)

* [AUI-1174](https://issues.liferay.com/browse/AUI-1174) Validate source code with JSHint
* [AUI-843](https://issues.liferay.com/browse/AUI-843) IO-Request module should accept either GET or get

## [2.5.0](https://github.com/liferay/alloy-ui/releases/tag/2.5.0)

* [AUI-1163](https://issues.liferay.com/browse/AUI-1163) Remove unnecessary constants